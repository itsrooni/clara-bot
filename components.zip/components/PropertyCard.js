export default function PropertyCard({ property }) {
  const {
    title,
    price,
    city,
    province,
    country,
    imageUrls
  } = property;

  const location = [city, province, country].filter(Boolean).join(', ');
  const image = imageUrls?.[0];

  return (
    <div className="border rounded-xl p-4 bg-white shadow-md mb-4 max-w-md">
      {image && (
        <img
          src={image}
          alt={title || 'Property Image'}
          className="w-full h-48 object-cover rounded-lg mb-3"
        />
      )}
      <h3 className="text-lg font-semibold">{title || 'Untitled Property'}</h3>
      <p className="text-sm text-gray-600">{location || 'Unknown Location'}</p>
      <p className="text-blue-700 font-bold mt-1">{price ? `€${price.toLocaleString()}` : 'Price not available'}</p>
      <button className="mt-3 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        View Property
      </button>
    </div>
  );
}
