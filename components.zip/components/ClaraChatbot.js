import { useState, useRef, useEffect } from 'react';
import { FaMicrophone, FaPaperPlane } from 'react-icons/fa';
import { GeminiChat } from '../utils/gemini';
import { loginUser, registerUser, searchProperties, searchCities } from '../lib/nestzone';
import PropertyCard from './PropertyCard';

export default function ClaraChatbot() {
  const [messages, setMessages] = useState([
    { sender: 'clara', text: 'Hello, welcome to Nestzone, how can I assist you?' }
  ]);
  const [input, setInput] = useState('');
  const [form, setForm] = useState(null);
  const [properties, setProperties] = useState([]);
  const synthRef = useRef(typeof window !== 'undefined' ? window.speechSynthesis : null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (synthRef.current) {
      synthRef.current.onvoiceschanged = () => synthRef.current.getVoices();
      speak('Hello, welcome to Nestzone, how can I assist you?');
    }
  }, []);

  const speak = (text) => {
    if (!text || !synthRef.current) return;

    const loadVoices = () => {
      const voices = synthRef.current.getVoices();
      let preferredVoice =
        voices.find(v => v.name.includes('Jenny')) ||
        voices.find(v => v.name.includes('Google UK English Female')) ||
        voices.find(v => v.name.toLowerCase().includes('female')) ||
        voices.find(v => v.name.includes('Microsoft Zira')) ||
        voices[0];

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      if (preferredVoice) utterance.voice = preferredVoice;
      synthRef.current.cancel();
      synthRef.current.speak(utterance);
    };

    if (synthRef.current.getVoices().length === 0) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    } else {
      loadVoices();
    }
  };

  const handleMicClick = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Your browser does not support speech recognition.');
      return;
    }

    if (!recognitionRef.current) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'en-US';
      recognitionRef.current.interimResults = false;
      recognitionRef.current.continuous = false;
      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
      };
    }

    try {
      recognitionRef.current.start();
    } catch (error) {
      if (error.name === 'InvalidStateError') {
        recognitionRef.current.stop();
        setTimeout(() => recognitionRef.current.start(), 200);
      } else {
        console.error(error);
      }
    }
  };

  const handleFormSubmit = async () => {
    if (form?.type === 'login') {
      const response = await loginUser(form.username, form.password);
      const reply = { sender: 'clara', text: response?.message || 'Logged in successfully.' };
      setMessages((prev) => [...prev, reply]);
      speak(reply.text);
      setForm(null);
      const next = { sender: 'clara', text: 'What else can I do for you?' };
      setMessages((prev) => [...prev, next]);
      speak(next.text);
    }
    if (form?.type === 'register') {
      const registrationData = {
        firstName: form.firstName,
        lastName: form.lastName,
        email: form.email,
        mobile: form.mobile,
        pass: form.pass,
        retypedPass: form.retypedPass,
        roleType: form.roleType,
        confirmedTermsAndConditions: form.confirmedTermsAndConditions,
        confirmedToGetUpdates: form.confirmedToGetUpdates
      };
      const response = await registerUser(registrationData);
      const reply = { sender: 'clara', text: response?.message || 'Registered successfully.' };
      setMessages((prev) => [...prev, reply]);
      speak(reply.text);
      setForm(null);
      const next = { sender: 'clara', text: 'How can I help you next?' };
      setMessages((prev) => [...prev, next]);
      speak(next.text);
    }
  };

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { sender: 'user', text: input }];
    setMessages(newMessages);
    setInput('');

    const lower = input.toLowerCase();

    if (lower.includes('login')) {
      setForm({ type: 'login', username: '', password: '' });
      return;
    }
    if (lower.includes('register')) {
      setForm({
        type: 'register',
        firstName: '',
        lastName: '',
        email: '',
        mobile: '',
        pass: '',
        retypedPass: '',
        roleType: '',
        confirmedTermsAndConditions: false,
        confirmedToGetUpdates: false
      });
      return;
    }

    try {
      const loc = await searchCities(input);
      const locationMatch = loc?.data?.find(item =>
        item.name.toLowerCase().includes('madrid')
      );

      const locationId = locationMatch?.id;

      if (locationId) {
        const results = await searchProperties({ locationId });
        const resultArray = Array.isArray(results?.data) ? results.data : [];

        setProperties(resultArray);

        const reply = {
          sender: 'clara',
          text: resultArray.length > 0
            ? `I found ${resultArray.length} properties.`
            : `Sorry, I couldn’t find any properties for that location.`
        };

        setMessages([...newMessages, reply]);
        speak(reply.text);

        if (resultArray.length > 0) {
          const combined = [
            ...newMessages,
            reply,
            ...resultArray.map(p => ({ sender: 'clara', text: `${p.title} for €${p.price}` }))
          ];
          const aiResponse = await GeminiChat(combined);
          const finalText = aiResponse.startsWith("I'm Clara") ? aiResponse : `I'm Clara. ${aiResponse}`;
          setMessages(prev => [...prev, { sender: 'clara', text: finalText }]);
          speak(finalText);
        }
        return;
      }
    } catch (err) {
      console.error('Location search error:', err);
    }

    const fallbackResponse = await GeminiChat([
      ...newMessages,
      ...properties.map(p => ({ sender: 'clara', text: `${p.title} - €${p.price}` }))
    ]);
    const fallbackText = fallbackResponse.startsWith("I'm Clara")
      ? fallbackResponse
      : `I'm Clara. ${fallbackResponse}`;
    setMessages([...newMessages, { sender: 'clara', text: fallbackText }]);
    speak(fallbackText);
  };

    return (
      <div className="fixed bottom-6 right-6 w-[350px] max-h-[90vh] bg-white shadow-2xl rounded-2xl flex flex-col overflow-hidden border border-gray-200 z-50">
        <div className="bg-blue-600 text-white px-4 py-3 text-lg font-semibold">Clara - Nestzone</div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2 text-sm">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`p-2 rounded-lg max-w-[85%] ${
                msg.sender === 'clara'
                  ? 'bg-blue-100 text-black self-start'
                  : 'bg-gray-200 text-black self-end ml-auto'
              }`}
            >
              {msg.text}
            </div>
          ))}

          {properties.map((prop, idx) => (
            <PropertyCard key={idx} property={prop} />
          ))}

          {form?.type === 'login' && (
            <div className="space-y-2">
              <input
                type="email"
                placeholder="Email"
                className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, username: e.target.value })}
              />
              <input
                type="password"
                placeholder="Password"
                className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, password: e.target.value })}
              />
              <button
                className="w-full bg-blue-600 text-white py-1 rounded"
                onClick={handleFormSubmit}
              >
                Login
              </button>
            </div>
          )}

          {form?.type === 'register' && (
            <div className="space-y-2">
              <input type="text" placeholder="First Name" className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, firstName: e.target.value })}
              />
              <input type="text" placeholder="Last Name" className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, lastName: e.target.value })}
              />
              <input type="email" placeholder="Email" className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, email: e.target.value })}
              />
              <input type="tel" placeholder="Phone" className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, mobile: e.target.value })}
              />
              <input type="password" placeholder="Password" className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, pass: e.target.value })}
              />
              <input type="password" placeholder="Confirm Password" className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, retypedPass: e.target.value })}
              />
              <input type="text" placeholder="Role Type" className="w-full px-2 py-1 border rounded"
                onChange={e => setForm({ ...form, roleType: e.target.value })}
              />
              <div className="flex gap-2 items-center">
                <input type="checkbox" onChange={e => setForm({ ...form, confirmedTermsAndConditions: e.target.checked })} />
                <label className="text-xs">Agree to terms</label>
              </div>
              <div className="flex gap-2 items-center">
                <input type="checkbox" onChange={e => setForm({ ...form, confirmedToGetUpdates: e.target.checked })} />
                <label className="text-xs">Get email updates</label>
              </div>
              <button
                className="w-full bg-green-600 text-white py-1 rounded"
                onClick={handleFormSubmit}
              >
                Register
              </button>
            </div>
          )}
        </div>

        <div className="p-2 border-t flex items-center gap-2">
          <button
            onClick={handleMicClick}
            className="text-blue-600 hover:text-blue-800"
          >
            <FaMicrophone />
          </button>
          <input
            type="text"
            className="flex-1 px-2 py-1 border rounded"
            placeholder="Type your message..."
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendMessage()}
          />
          <button
            onClick={sendMessage}
            className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
          >
            <FaPaperPlane />
          </button>
        </div>
      </div>
    );

}


// import { useState, useRef, useEffect } from 'react';
// import { FaMicrophone, FaPaperPlane } from 'react-icons/fa';
// import { GeminiChat } from '../utils/gemini';
// import { loginUser, registerUser, searchProperties, searchCities } from '../lib/nestzone';
// import PropertyCard from './PropertyCard';

// export default function ClaraChatbot() {
//   const [messages, setMessages] = useState([
//     { sender: 'clara', text: 'Hello, welcome to Nestzone, how can I assist you?' }
//   ]);
//   const [input, setInput] = useState('');
//   const [form, setForm] = useState(null);
//   const [properties, setProperties] = useState([]);
//   const synthRef = useRef(typeof window !== 'undefined' ? window.speechSynthesis : null);
//   const recognitionRef = useRef(null);

//   useEffect(() => {
//     if (synthRef.current) {
//       synthRef.current.onvoiceschanged = () => synthRef.current.getVoices();
//       speak('Hello, welcome to Nestzone, how can I assist you?');
//     }
//   }, []);

//   const speak = (text) => {
//     if (!text || !synthRef.current) return;

//     const loadVoices = () => {
//       const voices = synthRef.current.getVoices();
//       let preferredVoice =
//         voices.find(v => v.name.includes('Jenny')) ||
//         voices.find(v => v.name.includes('Google UK English Female')) ||
//         voices.find(v => v.name.toLowerCase().includes('female')) ||
//         voices.find(v => v.name.includes('Microsoft Zira')) ||
//         voices[0];

//       const utterance = new SpeechSynthesisUtterance(text);
//       utterance.lang = 'en-US';
//       if (preferredVoice) utterance.voice = preferredVoice;
//       synthRef.current.cancel();
//       synthRef.current.speak(utterance);
//     };

//     if (synthRef.current.getVoices().length === 0) {
//       window.speechSynthesis.onvoiceschanged = loadVoices;
//     } else {
//       loadVoices();
//     }
//   };

//   const handleMicClick = () => {
//     const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
//     if (!SpeechRecognition) {
//       alert('Your browser does not support speech recognition.');
//       return;
//     }

//     if (!recognitionRef.current) {
//       recognitionRef.current = new SpeechRecognition();
//       recognitionRef.current.lang = 'en-US';
//       recognitionRef.current.interimResults = false;
//       recognitionRef.current.continuous = false;
//       recognitionRef.current.onresult = (event) => {
//         const transcript = event.results[0][0].transcript;
//         setInput(transcript);
//       };
//     }

//     try {
//       recognitionRef.current.start();
//     } catch (error) {
//       if (error.name === 'InvalidStateError') {
//         recognitionRef.current.stop();
//         setTimeout(() => recognitionRef.current.start(), 200);
//       } else {
//         console.error(error);
//       }
//     }
//   };

//   const handleFormSubmit = async () => {
//     if (form?.type === 'login') {
//       const response = await loginUser(form.username, form.password);
//       const reply = { sender: 'clara', text: response?.message || 'Logged in successfully.' };
//       setMessages((prev) => [...prev, reply]);
//       speak(reply.text);
//       setForm(null);
//       const next = { sender: 'clara', text: 'What else can I do for you?' };
//       setMessages((prev) => [...prev, next]);
//       speak(next.text);
//     }
//     if (form?.type === 'register') {
//       const response = await registerUser({ name: form.name, email: form.email, password: form.password });
//       const reply = { sender: 'clara', text: response?.message || 'Registered successfully.' };
//       setMessages((prev) => [...prev, reply]);
//       speak(reply.text);
//       setForm(null);
//       const next = { sender: 'clara', text: 'How can I help you next?' };
//       setMessages((prev) => [...prev, next]);
//       speak(next.text);
//     }
//   };

//   const sendMessage = async () => {
//     if (!input.trim()) return;
//     const newMessages = [...messages, { sender: 'user', text: input }];
//     setMessages(newMessages);
//     setInput('');

//     const lower = input.toLowerCase();

//     if (lower.includes('login')) {
//       setForm({ type: 'login', username: '', password: '' });
//       return;
//     }
//     if (lower.includes('register')) {
//       setForm({ type: 'register', name: '', email: '', password: '' });
//       return;
//     }

//     try {
//       // Search all cities matching input
//       const loc = await searchCities(input);
//       console.log('City search result:', loc?.data);

//       // Try matching 'madrid' specifically
//       const locationMatch = loc?.data?.find(item =>
//         item.name.toLowerCase().includes('madrid')
//       );

//       const locationId = locationMatch?.id;
//       console.log('Matched locationId:', locationId);

//       if (locationId) {
//         const results = await searchProperties({ locationId });
//         const resultArray = Array.isArray(results?.data) ? results.data : [];
//         console.log('Properties found:', resultArray);

//         setProperties(resultArray);

//         const reply = {
//           sender: 'clara',
//           text: resultArray.length > 0
//             ? `I found ${resultArray.length} properties.`
//             : `Sorry, I couldn’t find any properties for that location.`
//         };

//         setMessages([...newMessages, reply]);
//         speak(reply.text);

//         // Only trigger GeminiChat if properties were found
//         if (resultArray.length > 0) {
//           const combined = [
//             ...newMessages,
//             reply,
//             ...resultArray.map(p => ({ sender: 'clara', text: `${p.title} for €${p.price}` }))
//           ];
//           const aiResponse = await GeminiChat(combined);
//           const finalText = aiResponse.startsWith("I'm Clara") ? aiResponse : `I'm Clara. ${aiResponse}`;
//           setMessages(prev => [...prev, { sender: 'clara', text: finalText }]);
//           speak(finalText);
//         }

//         return;
//       }
//     } catch (err) {
//       console.error('Location search error:', err);
//     }

//     // Fallback response if location fails
//     const fallbackResponse = await GeminiChat([
//       ...newMessages,
//       ...properties.map(p => ({ sender: 'clara', text: `${p.title} - €${p.price}` }))
//     ]);
//     const fallbackText = fallbackResponse.startsWith("I'm Clara")
//       ? fallbackResponse
//       : `I'm Clara. ${fallbackResponse}`;
//     setMessages([...newMessages, { sender: 'clara', text: fallbackText }]);
//     speak(fallbackText);
//   };

  // const sendMessage = async () => {
  //   if (!input.trim()) return;
  //   const newMessages = [...messages, { sender: 'user', text: input }];
  //   setMessages(newMessages);
  //   setInput('');

  //   const lower = input.toLowerCase();

  //   if (lower.includes('login')) {
  //     setForm({ type: 'login', username: '', password: '' });
  //     return;
  //   }
  //   if (lower.includes('register')) {
  //     setForm({ type: 'register', name: '', email: '', password: '' });
  //     return;
  //   }

  //   try {
  //     const loc = await searchCities("mad"); // Load Madrid and related locations
  //     const inputWords = input.toLowerCase().split(/\s+/);
  //     const locationMatch = loc?.data?.find(item =>
  //       inputWords.some(word => item.name.toLowerCase().includes(word))
  //     );

  //     const locationId = locationMatch?.id;
  //     if (locationId) {
  //       const results = await searchProperties({ locationId });
  //       const resultArray = Array.isArray(results) ? results : [];

  //       setProperties(resultArray);

  //       const reply = { sender: 'clara', text: `I found ${resultArray.length} properties.` };
  //       const combined = [
  //         ...newMessages,
  //         reply,
  //         ...resultArray.map(p => ({ sender: 'clara', text: `${p.title} for €${p.price}` }))
  //       ];

  //       setMessages([...newMessages, reply]);
  //       speak(reply.text);

  //       const aiResponse = await GeminiChat(combined);
  //       const finalText = aiResponse.startsWith("I'm Clara") ? aiResponse : `I'm Clara. ${aiResponse}`;
  //       setMessages(prev => [...prev, { sender: 'clara', text: finalText }]);
  //       speak(finalText);

  //       return; // ✅ EXIT HERE so fallback doesn't run
  //     }
  //   } catch (err) {
  //     console.error('Location search error:', err);
  //   }

  //   // 🟡 Fallback only if no location match or results found
  //   const fallbackResponse = await GeminiChat([
  //     ...newMessages,
  //     ...properties.map(p => ({ sender: 'clara', text: `${p.title} - €${p.price}` }))
  //   ]);
  //   const fallbackText = fallbackResponse.startsWith("I'm Clara") ? fallbackResponse : `I'm Clara. ${fallbackResponse}`;
  //   setMessages([...newMessages, { sender: 'clara', text: fallbackText }]);
  //   speak(fallbackText);
  // };


//   return (
//     <div className="fixed bottom-6 right-6 z-50 w-[370px] max-w-full shadow-xl rounded-xl border border-gray-300 bg-white flex flex-col">
//       <div className="bg-blue-600 text-white p-4 text-lg font-semibold rounded-t-xl">Clara - Assistant</div>
//       <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50 max-h-[60vh] scrollbar-thin">
//         {messages.map((msg, i) => (
//           <div key={i} className={msg.sender === 'user' ? 'text-right' : 'text-left'}>
//             <div className={msg.sender === 'user' ? 'bg-blue-600 text-white p-2 rounded-xl inline-block' : 'bg-white border p-2 rounded-xl inline-block'}>
//               {msg.text}
//             </div>
//           </div>
//         ))}
//         {form && (
//           <div className="space-y-2">
//             {form.type === 'register' && (
//               <input type="text" placeholder="Name" className="w-full p-2 border rounded" value={form.name}
//                      onChange={e => setForm({ ...form, name: e.target.value })} />
//             )}
//             <input type="email" placeholder="Email" className="w-full p-2 border rounded" value={form.email}
//                    onChange={e => setForm({ ...form, email: e.target.value })} />
//             <input type="password" placeholder="Password" className="w-full p-2 border rounded" value={form.password}
//                    onChange={e => setForm({ ...form, password: e.target.value })} />
//             <button onClick={handleFormSubmit} className="w-full bg-blue-600 text-white py-2 rounded">
//               Submit
//             </button>
//           </div>
//         )}
//         {Array.isArray(properties) && properties.map((prop, idx) => (
//           <PropertyCard key={idx} property={prop} />
//         ))}
//       </div>
//       <div className="p-3 flex items-center gap-2 border-t bg-white">
//         <button onClick={handleMicClick} className="text-blue-600" title="Speak">
//           <FaMicrophone />
//         </button>
//         <input
//           type="text"
//           value={input}
//           onChange={(e) => setInput(e.target.value)}
//           onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
//           placeholder="Type a message..."
//           className="flex-1 px-3 py-2 text-sm border rounded-lg"
//         />
//         <button onClick={sendMessage} className="text-blue-600" title="Send">
//           <FaPaperPlane />
//         </button>
//       </div>
//     </div>
//   );
// }


// import { useState, useRef, useEffect } from 'react';
// import { FaMicrophone, FaPaperPlane } from 'react-icons/fa';
// import { GeminiChat } from '../utils/gemini';
// import { loginUser, registerUser, searchProperties, searchCities } from '../lib/nestzone';
// import PropertyCard from './PropertyCard';

// export default function ClaraChatbot() {
//   const [messages, setMessages] = useState([
//     { sender: 'clara', text: 'Hello, welcome to Nestzone, how can I assist you?' }
//   ]);
//   const [input, setInput] = useState('');
//   const [form, setForm] = useState(null);
//   const [properties, setProperties] = useState([]);
//   const synthRef = useRef(typeof window !== 'undefined' ? window.speechSynthesis : null);
//   const recognitionRef = useRef(null);

//   useEffect(() => {
//     if (synthRef.current) {
//       synthRef.current.onvoiceschanged = () => synthRef.current.getVoices();
//       speak('Hello, welcome to Nestzone, how can I assist you?');
//     }
//   }, []);

//   const speak = (text) => {
//     if (!text || !synthRef.current) return;

//     const loadVoices = () => {
//       const voices = synthRef.current.getVoices();
//       let preferredVoice =
//         voices.find(v => v.name.includes('Jenny')) || // Chrome
//         voices.find(v => v.name.includes('Google UK English Female')) || // Chrome fallback
//         voices.find(v => v.name.toLowerCase().includes('female')) || // Generic fallback
//         voices.find(v => v.name.includes('Microsoft Zira')) || // Edge (Zira is female)
//         voices[0]; // Last fallback

//       const utterance = new SpeechSynthesisUtterance(text);
//       utterance.lang = 'en-US';
//       if (preferredVoice) utterance.voice = preferredVoice;
//       synthRef.current.cancel();
//       synthRef.current.speak(utterance);
//     };

//     if (synthRef.current.getVoices().length === 0) {
//       window.speechSynthesis.onvoiceschanged = loadVoices;
//     } else {
//       loadVoices();
//     }
//   };


//   const handleMicClick = () => {
//     const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
//     if (!SpeechRecognition) {
//       alert('Your browser does not support speech recognition.');
//       return;
//     }

//     if (!recognitionRef.current) {
//       recognitionRef.current = new SpeechRecognition();
//       recognitionRef.current.lang = 'en-US';
//       recognitionRef.current.interimResults = false;
//       recognitionRef.current.continuous = false;
//       recognitionRef.current.onresult = (event) => {
//         const transcript = event.results[0][0].transcript;
//         setInput(transcript);
//       };
//     }

//     try {
//       recognitionRef.current.start();
//     } catch (error) {
//       if (error.name === 'InvalidStateError') {
//         recognitionRef.current.stop();
//         setTimeout(() => recognitionRef.current.start(), 200);
//       } else {
//         console.error(error);
//       }
//     }
//   };

//   const handleFormSubmit = async () => {
//     if (form?.type === 'login') {
//       const response = await loginUser(form.username, form.password);
//       const reply = { sender: 'clara', text: response?.message || 'Logged in successfully.' };
//       setMessages((prev) => [...prev, reply]);
//       speak(reply.text);
//       setForm(null);
//       const next = { sender: 'clara', text: 'What else can I do for you?' };
//       setMessages((prev) => [...prev, next]);
//       speak(next.text);
//     }
//     if (form?.type === 'register') {
//       const response = await registerUser({ name: form.name, email: form.email, password: form.password });
//       const reply = { sender: 'clara', text: response?.message || 'Registered successfully.' };
//       setMessages((prev) => [...prev, reply]);
//       speak(reply.text);
//       setForm(null);
//       const next = { sender: 'clara', text: 'How can I help you next?' };
//       setMessages((prev) => [...prev, next]);
//       speak(next.text);
//     }
//   };

//   const sendMessage = async () => {
//     if (!input.trim()) return;
//     const newMessages = [...messages, { sender: 'user', text: input }];
//     setMessages(newMessages);
//     setInput('');

//     const lower = input.toLowerCase();

//     if (lower.includes('login')) {
//       setForm({ type: 'login', username: '', password: '' });
//       return;
//     }
//     if (lower.includes('register')) {
//       setForm({ type: 'register', name: '', email: '', password: '' });
//       return;
//     }

//     try {
//       const loc = await searchCities("mad"); // Load Madrid and related locations
//       const inputWords = input.toLowerCase().split(/\s+/);
//       const locationMatch = loc?.data?.find(item =>
//         inputWords.some(word => item.name.toLowerCase().includes(word))
//       );

//       const locationId = locationMatch?.id;
//       if (locationId) {
//         const results = await searchProperties({ locationId });
//         setProperties(Array.isArray(results) ? results : []); 

//         const reply = { sender: 'clara', text: `I found ${results.length} properties.` };
//         setMessages([...newMessages, reply]);
//         speak(reply.text);

//         const combined = [
//           ...newMessages,
//           reply,
//           ...results.map(p => ({ sender: 'clara', text: `${p.title} for €${p.price}` }))
//         ];
//         const aiResponse = await GeminiChat(combined);
//         const finalText = aiResponse.startsWith("I'm Clara") ? aiResponse : `I'm Clara. ${aiResponse}`;
//         setMessages(prev => [...prev, { sender: 'clara', text: finalText }]);
//         speak(finalText);
//         return;
//       }
//     } catch (err) {
//       console.error('Location search error:', err);
//     }

//     // If no location match found or error occurs
//     const fallbackResponse = await GeminiChat([
//       ...newMessages,
//       ...properties.map(p => ({ sender: 'clara', text: `${p.title} - €${p.price}` }))
//     ]);
//     const fallbackText = fallbackResponse.startsWith("I'm Clara") ? fallbackResponse : `I'm Clara. ${fallbackResponse}`;
//     setMessages([...newMessages, { sender: 'clara', text: fallbackText }]);
//     speak(fallbackText);
//   };




//   return (
//     <div className="fixed bottom-6 right-6 z-50 w-[370px] max-w-full shadow-xl rounded-xl border border-gray-300 bg-white flex flex-col">
//       <div className="bg-blue-600 text-white p-4 text-lg font-semibold rounded-t-xl">Clara - Assistant</div>
//       <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50 max-h-[60vh] scrollbar-thin">
//         {messages.map((msg, i) => (
//           <div key={i} className={msg.sender === 'user' ? 'text-right' : 'text-left'}>
//             <div className={msg.sender === 'user' ? 'bg-blue-600 text-white p-2 rounded-xl inline-block' : 'bg-white border p-2 rounded-xl inline-block'}>
//               {msg.text}
//             </div>
//           </div>
//         ))}
//         {form && (
//           <div className="space-y-2">
//             {form.type === 'register' && (
//               <input type="text" placeholder="Name" className="w-full p-2 border rounded" value={form.name}
//                      onChange={e => setForm({ ...form, name: e.target.value })} />
//             )}
//             <input type="email" placeholder="Email" className="w-full p-2 border rounded" value={form.email}
//                    onChange={e => setForm({ ...form, email: e.target.value })} />
//             <input type="password" placeholder="Password" className="w-full p-2 border rounded" value={form.password}
//                    onChange={e => setForm({ ...form, password: e.target.value })} />
//             <button onClick={handleFormSubmit} className="w-full bg-blue-600 text-white py-2 rounded">
//               Submit
//             </button>
//           </div>
//         )}
//         {properties.map((prop, idx) => (
//           <PropertyCard key={idx} property={prop} />
//         ))}
//       </div>
//       <div className="p-3 flex items-center gap-2 border-t bg-white">
//         <button onClick={handleMicClick} className="text-blue-600" title="Speak">
//           <FaMicrophone />
//         </button>
//         <input
//           type="text"
//           value={input}
//           onChange={(e) => setInput(e.target.value)}
//           onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
//           placeholder="Type a message..."
//           className="flex-1 px-3 py-2 text-sm border rounded-lg"
//         />
//         <button onClick={sendMessage} className="text-blue-600" title="Send">
//           <FaPaperPlane />
//         </button>
//       </div>
//     </div>
//   );
// }